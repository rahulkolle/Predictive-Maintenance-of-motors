# Predictive-Maintenance-of-Motor

<----Hey Hello there---->

This project can predict that your motor can work or fail.
This model works on the basis of a dataset attach with this project.
Unsupervised learning is used in this project.
Also a working of app is attached with this.


For any queries regard
contact : piyushsahani675@gmail.com
